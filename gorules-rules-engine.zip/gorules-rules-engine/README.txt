npm install @gorules/zen-engine

https://docs.gorules.io/reference/nodejs


-> jdm_graph.json

{
  "rules": [
    {
      "id": "loanEligibility",
      "conditions": {
        "all": [
          {
            "fact": "age",
            "operator": "greaterThan",
            "value": 21
          },
          {
            "fact": "creditScore",
            "operator": "greaterThan",
            "value": 700
          },
          {
            "fact": "income",
            "operator": "greaterThanOrEqual",
            "value": 50000
          },
          {
            "fact": "existingLoanAmount",
            "operator": "lessThanOrEqual",
            "value": 100000
          }
        ]
      },
      "actions": [
        {
          "type": "grantLoan",
          "message": "The customer is eligible for the loan."
        }
      ],
      "elseActions": [
        {
          "type": "denyLoan",
          "message": "The customer is not eligible for the loan based on current criteria."
        }
      ]
    }
  ]
}

-> This example will use the ZenEngine to load and evaluate the jdm_graph.json file against input data.

import { ZenEngine } from '@gorules/zen-engine';
import fs from 'fs/promises';

const main = async () => {
  // Read the JSON Decision Model (JDM) from the file
  const content = await fs.readFile('./jdm_graph.json', 'utf-8');

  // Initialize the ZEN Engine
  const engine = new ZenEngine();

  // Create a decision instance with the JDM content
  const decision = engine.createDecision(content);

  // Define input facts for a customer
  const customerData = {
    age: 30,
    creditScore: 750,
    income: 55000,
    existingLoanAmount: 90000
  };

  // Evaluate the decision with the customer's data
  const result = await decision.evaluate(customerData);

  console.log(result);
};

main();

