// types/rules.ts
export type Operator = 'equal' | 'notEqual' | 'greaterThan' | 'lessThan';

export interface Condition {
  fact: string;
  operator: Operator;
  value: any;
}

export interface Conditions {
  all?: Condition[];
  any?: Condition[];
}

export interface Action {
  type: string;
  message?: string;
}

export interface Rule {
  id: string;
  conditions: Conditions;
  actions: Action[];
}
