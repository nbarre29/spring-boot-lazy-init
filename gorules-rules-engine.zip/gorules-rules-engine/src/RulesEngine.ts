// src/RulesEngine.ts
import { Conditions, Action, Rule } from './types/rules';

export class RulesEngine {
  private rules: Rule[];

  constructor(rules: Rule[]) {
    this.rules = rules;
  }

  // Evaluate individual condition
  private evaluateCondition(
    factValue: any,
    operator: string,
    value: any
  ): boolean {
    switch (operator) {
      case 'equal':
        return factValue === value;
      case 'notEqual':
        return factValue !== value;
      case 'greaterThan':
        return factValue > value;
      case 'lessThan':
        return factValue < value;
      default:
        throw new Error(`Unknown operator: ${operator}`);
    }
  }

  // Evaluate all or any conditions in the rule
  private evaluateConditions(
    conditions: Conditions,
    facts: Record<string, any>
  ): boolean {
    const { all, any } = conditions;

    if (all) {
      return all.every((cond) =>
        this.evaluateCondition(facts[cond.fact], cond.operator, cond.value)
      );
    } else if (any) {
      return any.some((cond) =>
        this.evaluateCondition(facts[cond.fact], cond.operator, cond.value)
      );
    }

    return false;
  }

  // Execute actions for matching rules
  private executeActions(actions: Action[]): void {
    actions.forEach((action) => {
      if (action.type === 'notify' && action.message) {
        console.log(action.message);
      }
      // Add more action types if needed
    });
  }

  // Process rules based on given facts
  public processRules(facts: Record<string, any>): void {
    this.rules.forEach((rule) => {
      if (this.evaluateConditions(rule.conditions, facts)) {
        this.executeActions(rule.actions);
      }
    });
  }
}
