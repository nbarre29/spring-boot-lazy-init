// src/index.ts
import * as fs from 'fs';
import { RulesEngine } from './RulesEngine';
import { Rule } from './types/rules';

// Load rules from the JSON file
const rules: Rule[] = JSON.parse(fs.readFileSync('./src/rules.json', 'utf8'));

// Initialize rules engine
const engine = new RulesEngine(rules);

// Define facts
const facts = {
  age: 20,
  country: 'USA',
};

// Process rules
engine.processRules(facts);
